module fir_tree_accum_8 #(
    parameter TAP_INPUT_WIDTH,
    parameter NUM_TAP_INPUTS = 8,
    parameter OUTPUT_BIT_WIDTH
    
) (
    input wire clk_in,
    input wire rst_in,
    input wire signed [NUM_TAP_INPUTS - 1:0] [TAP_INPUT_WIDTH - 1:0] tap_values_in,
    output logic tree_accum_busy,
    output logic valid_out,
    output logic signed [OUTPUT_BIT_WIDTH - 1: 0] accum_out
);
    localparam NUM_CYCLES = $clog2(NUM_TAP_INPUTS);
    //number of accumulate terms
    localparam NUM_ACCUM_TERMS_STAGE1 = NUM_TAP_INPUTS >> 1; //4
    localparam NUM_ACCUM_TERMS_STAGE2 = NUM_TAP_INPUTS >> 2; //2

    //accumulation registers stage A
    logic signed [NUM_ACCUM_TERMS_STAGE1 - 1: 0] [TAP_INPUT_WIDTH + 1: 0] reg_sum_stage1;       //4 57-bits
    logic signed [NUM_ACCUM_TERMS_STAGE2 - 1: 0] [TAP_INPUT_WIDTH + 2: 0] reg_sum_stage2;       //2 58-bits

    //iterator variables
    logic [$clog2(NUM_ACCUM_TERMS_STAGE1) - 1: 0] i;
    logic [$clog2(NUM_ACCUM_TERMS_STAGE2) - 1: 0] j;

    //accumulation states
    typedef enum{
        STAGE1,
        STAGE2,
        OUTPUT
    } tree_accum_states;
    
    tree_accum_states state;

    always_ff @(posedge clk_in) begin
        if (rst_in) begin
            state <= STAGE1;
            reg_sum_stage1 <= 0;
            reg_sum_stage2 <= 0;

            tree_accum_busy <= 0;
            valid_out <= 0;
            accum_out <= 0;
        end else begin

            case (state) 
            
            STAGE1: begin
                tree_accum_busy <= 1;
                valid_out <= 0;

                if (i < NUM_ACCUM_TERMS_STAGE1 - 1) i <= i + 1; 
                else if (i == NUM_ACCUM_TERMS_STAGE1 - 1) begin
                    state <= STAGE2;
                    i <= 0;
                end

                
                reg_sum_stage1[i] <= $signed(tap_values_in[2*i]) + $signed(tap_values_in[2*i + 1]);
                
            end

            STAGE2: begin
                if (j < NUM_ACCUM_TERMS_STAGE2 - 1) j <= j + 1; 
                else if (j == NUM_ACCUM_TERMS_STAGE2 - 1) begin
                    state <= OUTPUT;
                    j <= 0;
                end

                reg_sum_stage2[j] <= $signed(reg_sum_stage1[2*j]) + $signed(reg_sum_stage1[2*j + 1]);

            end
            

            OUTPUT: begin
                tree_accum_busy <= 0;
                accum_out <= $signed(reg_sum_stage2[0]) + $signed(reg_sum_stage2[1]);
                valid_out <= 1;
                state <= STAGE1;
            end

            endcase
        end
    end

endmodule